Sample configuration files for:

SystemD: helleniccoind.service
Upstart: helleniccoind.conf
OpenRC:  helleniccoind.openrc
         helleniccoind.openrcconf
CentOS:  helleniccoind.init
OS X:    org.helleniccoin.helleniccoind.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
